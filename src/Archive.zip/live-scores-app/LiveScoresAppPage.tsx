import React, { useState, useEffect } from "react";
import DashboardCard from "./DashboardCard";


const applicationsData = [
  {
      "SYSTEM_ID": "1001",
      "SYSTEM_NAME": "SAP Business Intelligence (BI)",
      "DESCRIPTION": "Tool for performing analytics and reporting.",
      "SYSTEM_GROUP": "1",
      "SYSTEM_GROUP_ID": "SAP",
      "DOCUMENT_STORAGE": "NA",
      "DOCUMENT_STORAGE_METHOD": "",
      "IS_CORE_TOOL": "FALSE",
      "Authentication": "Not Applicable",
      "Vendor": "Accenture",
      "SYSTEM_STATUS": "Decomissioned",
      "SYSTEM_TYPE": "COTS",
      "BUSINESS_UNIT": "Information Systems and Services",
      "SYSTEM_OWNER": "Mark Ingram",
      "CHAMPION": "Mike Hopkins",
      "ANNUAL_SPEND": "100,000",
      "IMAGE_URL": "",
      "UPDATED_DATE": "",
      "CREATED_DATE": "",
      "REVIEW_STATUS": "COMPLETE"
  },
  {
      "SYSTEM_ID": "1002",
      "SYSTEM_NAME": "SAP ERP",
      "DESCRIPTION": "Legacy ERP for Finance and Asset management.",
      "SYSTEM_GROUP": "1",
      "SYSTEM_GROUP_ID": "SAP",
      "DOCUMENT_STORAGE": "NA",
      "DOCUMENT_STORAGE_METHOD": "",
      "IS_CORE_TOOL": "FALSE",
      "Authentication": "Not Applicable",
      "Vendor": "Accenture",
      "SYSTEM_STATUS": "Decomissioned",
      "SYSTEM_TYPE": "COTS",
      "BUSINESS_UNIT": "Information Systems and Services",
      "SYSTEM_OWNER": "Mark Ingram",
      "CHAMPION": "Mike Hopkins",
      "ANNUAL_SPEND": "125,000",
      "IMAGE_URL": "",
      "UPDATED_DATE": "",
      "CREATED_DATE": "",
      "REVIEW_STATUS": "COMPLETE"
  },
  {
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DESCRIPTION": "ERP for Finance, Asset Management and Procurement.",
      "SYSTEM_GROUP": "1",
      "SYSTEM_GROUP_ID": "SAP",
      "DOCUMENT_STORAGE": "Internal CMS",
      "DOCUMENT_STORAGE_METHOD": "",
      "IS_CORE_TOOL": "FALSE",
      "Authentication": "Azure AD",
      "Vendor": "Accenture",
      "SYSTEM_STATUS": "ACTIVE",
      "SYSTEM_TYPE": "PaaS",
      "BUSINESS_UNIT": "Information Systems and Services",
      "SYSTEM_OWNER": "Mark Ingram",
      "CHAMPION": "Mike Hopkins",
      "ANNUAL_SPEND": "260,000",
      "IMAGE_URL": "https://content.cdn.sap.com/is/image/sap/sap-s4hana-cloud-public-edition-lb-hmpg-producthero:XL?wid=1872&hei=1100&fit=stretch,1&fmt=png-alpha&resMode=sharp2",
      "UPDATED_DATE": "",
      "CREATED_DATE": "",
      "REVIEW_STATUS": "COMPLETE"
  }
]

const integrationsData = [
  {
      "INTEGRATION_ID": "10041",
      "SYSTEM_ID": "1004",
      "SYSTEM_NAME": "SAP BW4HANA",
      "DIRECTION": "Outbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "ETL (FME)",
      "FROM_SYSTEM_ID": "1004",
      "FROM_SYSTEM_DESCRIPTION": "SAP BW4HANA",
      "TO_SYSTEM_ID": "2000",
      "TO_SYSTEM_DESCRIPTION": "Snowflake",
      "INTEGRATION_SUMMARY": "Counter Data ingestion",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10042",
      "SYSTEM_ID": "1004",
      "SYSTEM_NAME": "SAP BW4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "API",
      "FROM_SYSTEM_ID": "2001",
      "FROM_SYSTEM_DESCRIPTION": "ESRI",
      "TO_SYSTEM_ID": "1004",
      "TO_SYSTEM_DESCRIPTION": "SAP BW4HANA",
      "INTEGRATION_SUMMARY": "NFPL Flattened outputs for SAC",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10031",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "SFTP Feed",
      "FROM_SYSTEM_ID": "1010",
      "FROM_SYSTEM_DESCRIPTION": "Jadestar",
      "TO_SYSTEM_ID": "1003",
      "TO_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "INTEGRATION_SUMMARY": "Employee details, Org structure & Payroll Journal",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10032",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Outbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "SFTP Feed",
      "FROM_SYSTEM_ID": "1003",
      "FROM_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "TO_SYSTEM_ID": "1010",
      "TO_SYSTEM_DESCRIPTION": "Jadestar",
      "INTEGRATION_SUMMARY": "Cost Center & WBS ingestion",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10033",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "API",
      "FROM_SYSTEM_ID": "1014",
      "FROM_SYSTEM_DESCRIPTION": "ARIS",
      "TO_SYSTEM_ID": "1003",
      "TO_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "INTEGRATION_SUMMARY": "Push Business Process into SAP Solman",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10034",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Outbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "API",
      "FROM_SYSTEM_ID": "1003",
      "FROM_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "TO_SYSTEM_ID": "1014",
      "TO_SYSTEM_DESCRIPTION": "ARIS",
      "INTEGRATION_SUMMARY": "Download process steps and bestp practise from SAP Solman",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10035",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "SFTP Feed",
      "FROM_SYSTEM_ID": "1019",
      "FROM_SYSTEM_DESCRIPTION": "Booking Services",
      "TO_SYSTEM_ID": "1003",
      "TO_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "INTEGRATION_SUMMARY": "Occupancy & Revenue for Finance",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10036",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "API",
      "FROM_SYSTEM_ID": "1013",
      "FROM_SYSTEM_DESCRIPTION": "DOCLearn",
      "TO_SYSTEM_ID": "1003",
      "TO_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "INTEGRATION_SUMMARY": "Skills & Qualification",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10037",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "Blutooth",
      "FROM_SYSTEM_ID": "1021",
      "FROM_SYSTEM_DESCRIPTION": "Counter Data",
      "TO_SYSTEM_ID": "1003",
      "TO_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "INTEGRATION_SUMMARY": "Bluetooth download of counter data into EAM",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10038",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "API",
      "FROM_SYSTEM_ID": "2001",
      "FROM_SYSTEM_DESCRIPTION": "ESRI",
      "TO_SYSTEM_ID": "1003",
      "TO_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "INTEGRATION_SUMMARY": "GEF Feature layers for EAM",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10039",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "TRUE",
      "INTEGRATION_TYPE": "SFTP Feed",
      "FROM_SYSTEM_ID": "EXT",
      "FROM_SYSTEM_DESCRIPTION": "Westpac Bank",
      "TO_SYSTEM_ID": "1003",
      "TO_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "INTEGRATION_SUMMARY": "Payment File (Not employee payments)",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10040",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Outbound",
      "IS_EXTERNAL_INTEGRATION": "TRUE",
      "INTEGRATION_TYPE": "SFTP Feed",
      "FROM_SYSTEM_ID": "EXT",
      "FROM_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "TO_SYSTEM_ID": "EXT",
      "TO_SYSTEM_DESCRIPTION": "Westpac Bank",
      "INTEGRATION_SUMMARY": "Payment acknowledgement file an Daily statements file",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10041",
      "SYSTEM_ID": "1003",
      "SYSTEM_NAME": "SAP S4HANA",
      "DIRECTION": "Inbound",
      "IS_EXTERNAL_INTEGRATION": "TRUE",
      "INTEGRATION_TYPE": "API",
      "FROM_SYSTEM_ID": "EXT",
      "FROM_SYSTEM_DESCRIPTION": "NIWA",
      "TO_SYSTEM_ID": "1003",
      "TO_SYSTEM_DESCRIPTION": "SAP S4HANA",
      "INTEGRATION_SUMMARY": "Fish Passage Assessment feature layer",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  },
  {
      "INTEGRATION_ID": "10101",
      "SYSTEM_ID": "1010",
      "SYSTEM_NAME": "Jadestar",
      "DIRECTION": "Outbound",
      "IS_EXTERNAL_INTEGRATION": "FALSE",
      "INTEGRATION_TYPE": "ETL (FME)",
      "FROM_SYSTEM_ID": "1010",
      "FROM_SYSTEM_DESCRIPTION": "Jadestar",
      "TO_SYSTEM_ID": "2000",
      "TO_SYSTEM_DESCRIPTION": "Snowflake",
      "INTEGRATION_SUMMARY": "Empoyee details and leave balances",
      "IS_PAYMENT_GATEWAY": "",
      "CREATED_DATE": "",
      "UPDATED_DATE": ""
  }
]

interface Application {
  SYSTEM_ID: string;
  SYSTEM_NAME: string;
  AUTHENTICATION: string;
  ANNUAL_SPEND: string;
  IMAGE_URL: string;
  documentStorage: string;
}

interface Integration {
  SYSTEM_ID: string;
  DIRECTION: string;
  IS_PAYMENT_GATEWAY: boolean;
}

const Dashboard: React.FC = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const getIntegrationCounts = (systemId: string) => {
    const inbound = integrationsData.filter(
      (int) => int.SYSTEM_ID === systemId && int.DIRECTION === "Inbound"
    ).length;

    const outbound = integrationsData.filter(
      (int) => int.SYSTEM_ID === systemId && int.DIRECTION === "Outbound"
    ).length;

    const hasPaymentGateway = integrationsData.some(
      (int) => int.SYSTEM_ID === systemId && int.IS_PAYMENT_GATEWAY
    );

    return { inbound, outbound, hasPaymentGateway };
  };

  return (
    <div className={`${isDarkMode ? "dark" : ""}`}>
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-10">
        {/* <button
          onClick={() => setIsDarkMode(!isDarkMode)}
          className="mb-8 px-4 py-2 bg-indigo-600 text-white rounded-md"
        >
          Toggle Dark Mode
        </button> */}

        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-8">
          Application Dashboard
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {applicationsData.map((app) => {
            const { inbound, outbound, hasPaymentGateway } =
              getIntegrationCounts(app.SYSTEM_ID);

            return (
              <DashboardCard
                key={app.SYSTEM_ID}
                title={app.SYSTEM_NAME}
                inboundCount={inbound}
                outboundCount={outbound}
                paymentGateway={hasPaymentGateway}
                authentication={app.Authentication}
                annualSpend={app.ANNUAL_SPEND}
                documentStorage={app.DOCUMENT_STORAGE}
                onClick={() => setSelectedImage(app.IMAGE_URL)}
              />
            );
          })}
        </div>

        {selectedImage && (
          <div className="mt-8">
            <img
              src={selectedImage}
              alt="Application"
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
