import React from "react";

interface DashboardCardProps {
  title: string;
  inboundCount: number;
  outboundCount: number;
  paymentGateway: boolean;
  authentication: string;
  annualSpend: string;
  documentStorage: string;
  onClick: () => void;
}

const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  inboundCount,
  outboundCount,
  paymentGateway,
  authentication,
  annualSpend,
  documentStorage,
  onClick,
}) => {
  return (
    <div
      className="p-4 sm:p-6 bg-white rounded-xl shadow-lg hover:shadow-2xl transform hover:-translate-y-1 transition-all duration-300 cursor-pointer"
      onClick={onClick}
    >
      {/* Content Section */}
      <h2 className="text-lg sm:text-xl font-bold text-gray-900">{title}</h2>

      <div className="mt-4 flex flex-col gap-2">
        <div className="flex justify-between">
          <span className="font-semibold text-gray-700">Inbound:</span>
          <span className="text-gray-600">{inboundCount}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-semibold text-gray-700">Outbound:</span>
          <span className="text-gray-600">{outboundCount}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-semibold text-gray-700">Payment Gateway:</span>
          <span className={`font-medium ${paymentGateway ? "text-green-500" : "text-red-500"}`}>
            {paymentGateway ? "Yes" : "No"}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="font-semibold text-gray-700">Authentication:</span>
          <span className="text-gray-600">{authentication}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-semibold text-gray-700">Document Storage:</span>
          <span className="text-gray-600">{documentStorage}</span>
        </div>
      </div>

      <p className="text-3xl font-bold text-indigo-600 mt-4">
        ${annualSpend.toLocaleString()}
      </p>
      <span className="text-gray-600">(Annual Spend)</span>
    </div>
  );
};

export default DashboardCard;
